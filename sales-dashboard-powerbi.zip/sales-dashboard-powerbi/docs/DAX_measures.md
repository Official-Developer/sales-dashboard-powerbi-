# DAX Measures — Sales Performance Dashboard

## Basic KPI Measures

```dax
-- Total Sales
Total Sales = SUM(Sales[Total_Sales])

-- Total Orders
Total Orders = DISTINCTCOUNT(Sales[Order_ID])

-- Average Order Value
Avg Order Value = DIVIDE([Total Sales], [Total Orders], 0)

-- Total Quantity Sold
Total Quantity = SUM(Sales[Quantity])
```

---

## Time Intelligence Measures

```dax
-- Sales Last Month
Sales Last Month =
CALCULATE(
    [Total Sales],
    PREVIOUSMONTH(Sales[Date])
)

-- Month-over-Month Growth %
MoM Growth % =
DIVIDE(
    [Total Sales] - [Sales Last Month],
    [Sales Last Month],
    0
) * 100

-- Sales Same Period Last Year
Sales LY =
CALCULATE(
    [Total Sales],
    SAMEPERIODLASTYEAR(Sales[Date])
)

-- Year-over-Year Growth %
YoY Growth % =
DIVIDE(
    [Total Sales] - [Sales LY],
    [Sales LY],
    0
) * 100

-- Year-to-Date Sales
YTD Sales =
TOTALYTD([Total Sales], Sales[Date])

-- Quarter-to-Date Sales
QTD Sales =
TOTALQTD([Total Sales], Sales[Date])
```

---

## Ranking Measures

```dax
-- Top Product by Sales
Top Product =
CALCULATE(
    FIRSTNONBLANK(Sales[Product], 1),
    TOPN(1, ALL(Sales[Product]), [Total Sales], DESC)
)

-- Product Sales Rank
Product Rank =
RANKX(
    ALL(Sales[Product]),
    [Total Sales],
    ,
    DESC,
    DENSE
)
```

---

## Regional Measures

```dax
-- Region Sales Share %
Region Share % =
DIVIDE(
    [Total Sales],
    CALCULATE([Total Sales], ALL(Sales[Region])),
    0
) * 100
```

---

## Power Query Steps (M Code)

```m
// Load and transform Sales data
let
    Source = Excel.Workbook(File.Contents("data/sales_data.xlsx"), null, true),
    Sales_Sheet = Source{[Item="Sales",Kind="Sheet"]}[Data],
    Promoted_Headers = Table.PromoteHeaders(Sales_Sheet, [PromoteAllScalars=true]),
    Changed_Types = Table.TransformColumnTypes(Promoted_Headers,{
        {"Order_ID", Int64.Type},
        {"Date", type date},
        {"Region", type text},
        {"Product", type text},
        {"Category", type text},
        {"Quantity", Int64.Type},
        {"Unit_Price", Int64.Type},
        {"Total_Sales", Int64.Type},
        {"Customer_Name", type text}
    }),
    Added_Month = Table.AddColumn(Changed_Types, "Month", each Date.MonthName([Date]), type text),
    Added_Quarter = Table.AddColumn(Added_Month, "Quarter",
        each "Q" & Text.From(Date.QuarterOfYear([Date])), type text),
    Added_Year = Table.AddColumn(Added_Quarter, "Year",
        each Date.Year([Date]), Int64.Type)
in
    Added_Year
```
