# 📊 Sales Performance Dashboard — Power BI

## Overview
Interactive Power BI dashboard to monitor key sales KPIs including
Total Sales, Orders, Average Order Value, and Monthly Revenue Trends.
Built with DAX measures, Power Query transformations, and time intelligence.

## Tech Stack
- **Power BI Desktop** — Dashboard Design, Interactive Visuals
- **DAX** — KPI Measures, Time Intelligence
- **Power Query (M)** — Data Transformation & Cleaning
- **Excel** — Data Source

## Project Structure
```
sales-dashboard-powerbi/
├── data/
│   └── sales_data.xlsx        ← Connect this in Power BI
├── dashboard/
│   └── Sales_Dashboard.pbix   ← Main Power BI file
├── screenshots/
│   └── dashboard_preview.png
├── docs/
│   └── DAX_measures.md        ← All DAX formulas documented
└── README.md
```

## Dashboard Features
| Feature | Description |
|---------|-------------|
| 📌 KPI Cards | Total Sales, Orders, Avg Order Value, Total Qty |
| 📈 Line Chart | Monthly Sales Trend with MoM comparison |
| 🗺️ Bar Chart | Region-wise Revenue Breakdown |
| 🥧 Pie Chart | Category split (Electronics vs Furniture) |
| 🏆 Table | Top Products by Revenue |
| 🔘 Slicers | Filter by Region, Category, Month, Quarter |

## DAX Measures Used
- `Total Sales`, `Total Orders`, `Avg Order Value`
- `Sales Last Month`, `MoM Growth %`
- `YTD Sales`, `QTD Sales`
- `YoY Growth %`, `Region Share %`
- `Product Rank`

👉 Full DAX code → [docs/DAX_measures.md](docs/DAX_measures.md)

## How to Use

1. **Clone the repo**
   ```
   git clone https://github.com/your-username/sales-dashboard-powerbi.git
   ```

2. **Open Power BI Desktop**

3. **Load the data**
   - Get Data → Excel → select `data/sales_data.xlsx`
   - Apply Power Query transformations from `docs/DAX_measures.md`

4. **Build or open dashboard**
   - Open `dashboard/Sales_Dashboard.pbix`
   - Refresh data source path if needed

## Key Insights from Data
- 📈 December recorded the highest monthly revenue
- 🏆 Laptop is the top-selling product
- 🗺️ North region leads in total sales
- ⚡ Electronics category contributes ~65% of total revenue

## Author
**Tulsi Harel**
📧 tulsiharel5@gmail.com
🔗 [LinkedIn](https://linkedin.com/in/tulsi-harel)
